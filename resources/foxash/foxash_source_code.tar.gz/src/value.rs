use std::collections::BTreeMap;
use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Text(String),
    Number(f64),
    Boolean(bool),
    List(Vec<Value>),
    Object(BTreeMap<String, Value>),
    Window,
    GraphicBox,
    Button,
    Nothing,
}

impl fmt::Display for Value {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Text(value) => write!(formatter, "{}", value),

            Value::Number(value) => {
                if value.fract() == 0.0 {
                    write!(formatter, "{}", *value as i64)
                } else {
                    write!(formatter, "{}", value)
                }
            }

            Value::Boolean(value) => write!(formatter, "{}", value),

            Value::List(values) => {
                write!(formatter, "[")?;

                for (index, value) in values.iter().enumerate() {
                    if index > 0 {
                        write!(formatter, ", ")?;
                    }

                    write!(formatter, "{}", value)?;
                }

                write!(formatter, "]")
            }

            Value::Object(values) => {
                write!(formatter, "{{")?;

                for (index, (key, value)) in values.iter().enumerate() {
                    if index > 0 {
                        write!(formatter, ", ")?;
                    }

                    write!(formatter, "{}: {}", crate::json::quote(key), value)?;
                }

                write!(formatter, "}}")
            }

            Value::Window => write!(formatter, "window"),
            Value::GraphicBox => write!(formatter, "box"),
            Value::Button => write!(formatter, "button"),

            Value::Nothing => write!(formatter, "nothing"),
        }
    }
}
